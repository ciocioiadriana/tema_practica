
CREATE TABLE `angajat` (
  `Nume` varchar(30) NOT NULL,
  `Prenume` varchar(30) NOT NULL,
  `Departamen` varchar(50) NOT NULL,
  `Varsta` int(11) NOT NULL,
  `Salariu` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `angajat` (`Nume`, `Prenume`, `Departamen`, `Varsta`, `Salariu`) VALUES
('Costea', 'Ion', 'Contabilitate si financiar', 39, 1500),
('Panait ', 'George', 'Resurse umane', 28, 2200),
('Baciu', 'Andrei', 'IT', 26, 3000),
('Chirila', 'Alexandru', 'Vanzari externe', 31, 1800),
('Ionescu', 'Ioana', 'Receptie si depozitare', 25, 1500),
('Popescu', 'Adriana', 'Director general', 40, 5500),
('Ivanov', 'Ionut', 'Administratie', 32, 2000),
('Dinescu', 'Dumitru', 'Transport', 28, 1500),
('Voica', 'Aurelia', 'Director economic', 45, 3000),
('Staicu', 'Ionut-Daniel', 'Transport', 26, 1500);

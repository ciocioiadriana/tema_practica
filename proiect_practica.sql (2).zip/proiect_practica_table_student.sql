
CREATE TABLE `student` (
  `ID` int(11) NOT NULL,
  `Nume` varchar(30) NOT NULL,
  `Prenume` varchar(30) NOT NULL,
  `Grupa` varchar(10) NOT NULL,
  `Media` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `student` (`ID`, `Nume`, `Prenume`, `Grupa`, `Media`) VALUES
(1, 'Popa', 'Laurentiu', 'CR 2.1', 8),
(2, 'Ionescu', 'Ionut', 'CE 2.2', 7.2),
(3, 'Popescu', 'Stefan Alexandru', 'CR 2.2', 8.1),
(4, 'Panait ', 'Ioana', 'CR 2.1', 9),
(5, 'Gadea', 'Mihai-Petre', 'CR 2.2', 8.89),
(6, 'Negru', 'Doina Bianca', 'CE 2.1', 6.9),
(7, 'Dragulescu', 'Adriana Elena', 'CR 2.1', 9.1),
(8, 'Georgescu', 'Roxana Madalina', 'CR 2.1', 8.5),
(9, 'Petrescu', 'Mihnea', 'CR 2.1', 8.78),
(10, 'Popescu', 'Liviu-Andrei', 'CE 2.2', 9);

USE `phpmyadmin`;

INSERT INTO `pma__table_uiprefs` (`username`, `db_name`, `table_name`, `prefs`, `last_update`) VALUES
('root', 'proiect_practica', 'biblioteca', '{\"sorted_col\":\"`biblioteca`.`Categoria`  ASC\"}', '2017-07-03 15:41:24');


CREATE TABLE `biblioteca` (
  `Titlul` varchar(50) NOT NULL,
  `Autor` varchar(50) NOT NULL,
  `Categoria` varchar(50) NOT NULL,
  `Editura` varchar(50) NOT NULL,
  `Numar_Raft` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `biblioteca` (`Titlul`, `Autor`, `Categoria`, `Editura`, `Numar_Raft`) VALUES
('Inainte sa te cunosc', 'Jojo Moyes', 'Romantica', 'LITERA', 5),
('Micul Print', 'Antoine de Saint-Exupery', 'Literatura Universala', 'REGIS', 50),
('Povesti cu talc', 'Petre Ispirescu', 'Literatura Romana', 'REGIS', 143),
('Maitreyi ', 'Mircea Eliade', 'Literatura Romana', 'TANA', 10),
('Povestea Faridei ', 'Farida Khalaf', 'Memorii Jurnal', 'RAO', 2),
('Amintiri din copilarie', 'Ion Creanga', 'Literatura Romana', 'REGIS', 54),
('Noul Cod Rutier 2017 pe intelesul tuturor ', 'Marius Stanculescu', ' Legislatie Rutiera', 'TEOCORA', 23),
('Baltagul', 'Mihail Sadoveanu', 'Literatura Romana', 'MIHAIL SADOVEANU', 2),
('Poezii', 'Mihai Eminescu', 'Literatura Romana', 'REGIS', 4);

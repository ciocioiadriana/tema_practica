
CREATE TABLE `adresa` (
  `Strada` varchar(30) NOT NULL,
  `Bloc` varchar(30) NOT NULL,
  `Scara` int(11) NOT NULL,
  `Etaj` int(11) NOT NULL,
  `Apartament` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `adresa` (`Strada`, `Bloc`, `Scara`, `Etaj`, `Apartament`) VALUES
('Ion Tuculescu', '1 IUG', 1, 4, 400),
('Iancu Jianu', '88', 2, 2, 10),
('Iuliu Cezar', '3', 1, 4, 17),
('Lalelelor', '45 D', 4, 2, 8),
('Lapus Arges', '5', 3, 2, 5),
('Lipscani', '56 C', 2, 4, 17),
('Maiorescu Ion', '10 A', 3, 3, 13),
('Petru Rares', '5 A1', 3, 4, 15);
